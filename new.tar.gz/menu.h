#include <ncurses.h>
#include <menu.h>
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#define CTRLD 	4

int menu();
void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string);

