#include "game.h"

int battle_PvP(int n) {

	WINDOW *players_win; 	// deklaracja planszy gracza 
	WINDOW *enemys_win;		// deklaracja planszy przeciwnika
	int **players_board;  	// tablica pol gracza
	int **enemys_board;		// tablica pol przeciwnika
	int height;				// wysokosc planszy
	int width;				// szerokosc planszy
	int result;				// wynik rozgrywki
	int i;

	height 	= step_up_down * n + 1;
	width 	= step_left_right * n + 1;

	/* Deklaracja tablicy n x n do przechowywania danych o statkach dla gracza */
	players_board=(int **)calloc(n+4,sizeof(int));
	for (i=0 ; i < n+4 ; i++) {
		players_board[i] = (int *)calloc(n+4, sizeof(int));		
	}

	/* Deklaracja tablicy n x n do przechowywania danych o statkach dla przeciwnika */
	enemys_board=(int **)calloc(n+4,sizeof(int));
	for (i=0 ; i < n+4 ; i++) {
		enemys_board[i] = (int *)calloc(n+4, sizeof(int));
	}

	//players_win = set_board_player( height, width, starty_main, COLS - startx_main - width, players_board, n);
	// enemys_win 	= set_board_player( height, width, starty_main, startx_main, enemys_board, n);

	// start_playing();

	getch();	

	destroy_win(players_win, n);
	destroy_win(enemys_win, n);

	free(enemys_board);
	free(players_board);
	
	endwin();	
}

// Creating new window
WINDOW *create_newwin(int height, int width, int starty_main, int startx_main, int n) {
	
	WINDOW *local_win;
	int i=0, j=0;

	local_win = newwin(height, width, starty_main, startx_main);
	box(local_win, 0 , 0);

	for (j=1 ; j<(step_up_down*n) ; j++)
		{	
			if ((j%2) == 0)
			
				for (i=1 ; i<(step_left_right*n) ; i++)
					{
						mvwaddch(local_win,j,i,ACS_HLINE);
						mvwaddch(local_win,j,i,ACS_HLINE);
						mvwaddch(local_win,j,i,ACS_HLINE);
						mvwaddch(local_win,j,i,ACS_HLINE);
					}
			else		
			
				for (i=0 ; i<(step_left_right*n) ; i++)
					{
						if ((i%4) == 0)
							mvwaddch(local_win,j,i,ACS_VLINE);
						else
							mvwaddch(local_win,j,i,' ');
					}
					
		}
	wrefresh(local_win);

	return local_win;
}

// Checking if currently toggled ship had some horizontal neightbours
int check_if_around_pos_horizont(int **tab, int starty, int startx, int size) {
	int i;
	int state = 0;
	
	for (i=0 ; i<size ; i++) {

		if (tab[starty][startx + i]==2) {
			state=1;
		}
	}
	
	return state;
}

// Checking if currently toggled ship had some vertical neightbours
int check_if_around_pos_vertical(int **tab, int starty, int startx, int size) {
	int i;
	int state = 0;
	
	for (i=0 ; i<size ; i++) {

		if (tab[starty +i][startx]==2) {
			state=1;
		}
	}
	
	return state;
}

// Destroying window
void destroy_win(WINDOW *local_win, int n) {	
	int i, j;
	
	for (j=1 ; j<2*n ; j++) {
	
			if ((j%2) == 0) {
			
				for (i=1 ; i<4*n ; i++) {
				
						mvwaddch(local_win,j,i,' ');
						mvwaddch(local_win,j,i,' ');
						mvwaddch(local_win,j,i,' ');
						mvwaddch(local_win,j,i,' ');
					}
			}

			else {
			
				for (i=0 ; i<4*n ; i++) {
	
					if ((i%4) == 0) {
						mvwaddch(local_win,j,i,' ');
					}				
					else {
						mvwaddch(local_win,j,i,' ');
					}			
				}
			}		
	}
	
	wborder(local_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
	wrefresh(local_win);
	delwin(local_win);
}

/*
WINDOW *set_board_player(int height, int width, int starty_main, int startx_main, int **tab, int n) {	
	//direction - zmienna pobierająca klawisz od gracza
	//flag_s, flag_ty, flag_tx - flagi przekazujące informację czy na drodze statku nie ma przeszkód w postaci innych statków
	//starty, startx - przechowują aktualne współrzędne statku (kursora)
	//players_ships - ilość statków na planszy, size_of_ship - rozmiar aktualnie ustawianego statku
	//vertical - zmienna przyjmująca wartości TRUE/FALSE i mówiąca o pionowym/poziomym ustawieniu statku
	//flagx, flagy - potrzebne do sprawdzenia przy ustawianiu statku czy nie ma żadnych statków w pobliżu
	//local_win - wskaźnik na okno gracza
	int direction, flag_s, flag_ty, flag_tx, starty, startx;
	int players_ships=0, vertical=FALSE, size_of_ship=4, flagx=0, flagy=0;
	WINDOW *local_win;
	
	local_win = create_newwin(height,width,starty_main,startx_main);
	
	starty = 1;
	startx = 2;
	
	for (i=0 ; i < (size_of_ship); i++) {
		
		mvwaddch(local_win,starty,startx,ACS_CKBOARD);
		tab[rtomy(starty)][rtomx(startx)]=2;
		startx = startx + step_left_right;
	}

	startx = startx - (size_of_ship)*step_left_right;
	wrefresh(local_win);
		
	while( ((direction = getch()) != EOF)  &&  players_ships<20) {	
							
		switch(direction) {	
			
			case KEY_LEFT:
			
				for(i=0 ; i<size_of_ship ; i++) {
				
					if (tab[rtomy(starty)+i][rtomx(startx)-1]==1) {
						flag_s=TRUE;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					
					if (tab[rtomy(starty)+i][n]==1) {
						flag_ty=TRUE;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[rtomy(starty)][n-i]==1) {
							flag_tx=TRUE;
					}
				}	
					
				if (vertical==TRUE && flag_s!=TRUE) {		
					
					//usuwanie statku z planszy
					for (i=0 ; i< (size_of_ship) ; i++) {	
						mvwaddch(local_win,starty,startx,' ');
						starty = starty + step_up_down;								
					}	
					
					starty = starty - step_up_down;
					
					//ustawienie kursora
					if(rtomx(startx)==1 && torus==TRUE && flag_ty!=TRUE) {
						startx = mtorx(n);
					}
					else if(rtomx(startx)!=1) {
						startx = startx - step_left_right;
					}

					//rysowanie nowego statku
					for (i=0 ; i<(size_of_ship) ; i++) {
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);
						starty = starty - step_up_down;
					}
					
					starty = starty + step_up_down;
					wrefresh(local_win);								
				}
				
				// zestaw działań gdy statek jest poziomo
				if (vertical==FALSE && tab[rtomy(starty)][rtomx(startx) - 1]!=1 ) {
					
					if(torus==TRUE && rtomx(startx)==1 && flag_tx!=TRUE) {

						for(i=0 ; i<=size_of_ship ; i++) {
							mvwaddch(local_win,starty,startx,' '); startx=startx+step_left_right;}							
							startx=mtorx(n-(size_of_ship-1));
						}						

						for(i=0 ; i<=size_of_ship ; i++) {
							mvwaddch(local_win,starty,startx,ACS_CKBOARD); 
							startx=startx+step_left_right;
						}

						startx=mtorx(n-(size_of_ship-1));
						wrefresh(local_win);
					} else if(rtomx(startx)!=1) {
						startx = startx + (size_of_ship - 1)*step_left_right;
						mvwaddch(local_win,starty,startx,' ');															
						startx = startx - size_of_ship*step_left_right;
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);
					}
 
					wrefresh(local_win);				
				}
	
				flag_s=FALSE;
				flag_tx=FALSE;
				flag_ty=FALSE;
				
				break;
				
			case KEY_RIGHT:
			
				for(i=0 ; i<size_of_ship ; i++) {
					if (tab[rtomy(starty)+i][rtomx(startx) + 1]==1) {	
						flag_s=TRUE;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[rtomy(starty)+i][1]==1) {
						flag_ty=TRUE;
					}					
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[rtomy(starty)][1+i]==1) {
						flag_tx=TRUE;
					}
				}
				
				// sprawdzenie czy w wypadku gdy statek jest pionowo nie jest przy prawej krawedzi planszy i wartosci flagi
				if (vertical==TRUE && flag_s!=TRUE) {
					for (i=0 ; i< (size_of_ship) ; i++) {
						mvwaddch(local_win,starty,startx,' ');
						starty = starty + step_up_down;								
					}															
							
					starty = starty - step_up_down;
							
					if(rtomx(startx)==n && torus==TRUE && flag_ty!=TRUE) {							
						startx=mtorx(1);
					} 
					else if(rtomx(startx)!=n) {
						startx = startx + step_left_right;
								
						for (i=0 ; i<(size_of_ship) ; i++) {
							mvwaddch(local_win,starty,startx,ACS_CKBOARD);
							starty = starty - step_up_down;
						}

						starty = starty + step_up_down;
						wrefresh(local_win);
					}

					if (vertical==FALSE && tab[rtomy(starty)][rtomx(startx) + size_of_ship]!=TRUE) {			
						if((rtomx(startx)==n+1-size_of_ship) && torus==TRUE && flag_tx!=TRUE) {
							for(i=0 ; i<size_of_ship ; i++) {
								mvwaddch(local_win,starty,startx,' '); 
								startx=startx+step_left_right;
							}							
							
							startx=mtorx(1);

							for(i=0 ; i<size_of_ship ; i++) {
								mvwaddch(local_win,starty,startx,ACS_CKBOARD); 
								startx=startx+step_left_right;
							}

							startx=mtorx(1);
							wrefresh(local_win);
						}	
																					
						else if(rtomx(startx)!=n+1-size_of_ship) {
							mvwaddch(local_win,starty,startx,' ');
							startx = startx + size_of_ship*step_left_right;
							mvwaddch(local_win,starty,startx,ACS_CKBOARD); 
							wrefresh(local_win);	
							startx = startx - (size_of_ship - 1)*step_left_right;
							mvwaddch(local_win,starty,startx,ACS_CKBOARD);
							wrefresh(local_win);
						}
				}
				
				flag_s=FALSE;
				flag_tx=FALSE;
				flag_ty=FALSE;

				break;
				
			case KEY_UP:
			
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[rtomy(starty) - 1][rtomx(startx)+i]==1) {
							flag_s=1;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[n][rtomx(startx)+i]==1) {
							flag_tx=TRUE;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[n-i][rtomx(startx)]==1) {
						flag_ty=TRUE;
					}
				}
					
				if (vertical==TRUE && tab[rtomy(starty)-1][rtomx(startx)]!=TRUE) {
					if(torus==TRUE && rtomy(starty)==1 && flag_ty!=TRUE) {
						for(i=0 ; i<size_of_ship ; i++) {
							mvwaddch(local_win,starty,startx,' '); 
							starty=starty+step_up_down;
						}

						starty=mtory(n+1-size_of_ship);
						
						for(i=0 ; i<size_of_ship ; i++) {
							mvwaddch(local_win,starty,startx,ACS_CKBOARD); 
							starty=starty+step_up_down;
						}
						
						starty=mtory(n+1-size_of_ship);	
						wrefresh(local_win);
					}	
																		
					else if(rtomy(starty)!=1) {
						starty = starty + step_up_down*(size_of_ship-1);
						mvwaddch(local_win,starty,startx,' ');
						starty = starty - step_up_down*(size_of_ship);
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);
						wrefresh(local_win);
					}
				}	
				
				if (vertical==FALSE && flag_s!=TRUE) {
					for (i=0 ; i< (size_of_ship - 1) ; i++) {
						mvwaddch(local_win,starty,startx,' ');	
						startx = startx + step_left_right;
					}
							
					mvwaddch(local_win,starty,startx,' ');	
							
					if(torus==TRUE && rtomy(starty)==1 && flag_tx!=TRUE) {
						starty=mtory(n);
					}
							
					else if(rtomy(starty)!=1) {
						starty = starty - step_up_down;
					}
					
					for (i=0 ; i< (size_of_ship -1) ; i++) {
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);
						startx = startx - step_left_right;
					}
					
					mvwaddch(local_win,starty,startx,ACS_CKBOARD);
					wrefresh(local_win);
				}	
				
				flag_s=FALSE;
				flag_tx=FALSE;
				flag_ty=FALSE;

				break;
				
			case KEY_DOWN:
			
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[rtomy(starty) + 1][rtomx(startx)+i]==1) {
						flag_s=1;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[1][rtomx(startx)+i]==1) {
						flag_tx=TRUE;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[1+i][rtomx(startx)]==1) {
						flag_ty=TRUE;
					}
				}

				if (vertical==TRUE && tab[rtomy(starty)+size_of_ship][rtomx(startx)]!=1) {
	
					if(torus==TRUE && rtomy(starty)==n+1-size_of_ship && flag_ty!=TRUE) {
						
						for(i=0 ; i<size_of_ship ; i++) {
							mvwaddch(local_win,starty,startx,' '); 
							starty=starty+step_up_down;}
							starty=mtory(1);
						}
	
						for(i=0 ; i<size_of_ship ; i++) {
							mvwaddch(local_win,starty,startx,ACS_CKBOARD); 
							starty=starty+step_up_down;
						}

						starty=mtory(1);	
						wrefresh(local_win);
					}
					
					else if(rtomy(starty)!=n+1-size_of_ship) {
	
						mvwaddch(local_win,starty,startx,' ');
						starty = starty + step_up_down*(size_of_ship);				
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);
						starty = starty - step_up_down*(size_of_ship-1);
						wrefresh(local_win);
					}
				}
					
				if (vertical==FALSE && tab[rtomy(starty) + 1][rtomx(startx)]!=1 &&  flag_s!=TRUE) {
					
					for (i=0 ; i< (size_of_ship - 1) ; i++) {
						mvwaddch(local_win,starty,startx,' ');	
						startx = startx + step_left_right;
					}
							
					mvwaddch(local_win, starty,startx,' ');	
							
					if(torus==TRUE && rtomy(starty)==n && flag_tx!=TRUE) {
						starty=rtomy(1);
					}
					
					else if(rtomy(starty)!=n) {
						starty = starty + step_up_down;
							
						for (i=0 ; i< (size_of_ship -1) ; i++) {
							mvwaddch(local_win,starty,startx,ACS_CKBOARD);
							startx = startx - step_left_right;
						}

						mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
						wrefresh(local_win);	
					}
				}

				flag_s=FALSE;
				flag_tx=FALSE;
				flag_ty=FALSE;

				break;	
			
//			case 'p':
//			mvwprintw(stdscr,1,0,"Wartosc punktu to: starty = %d  startx = %d rtormy = %d rtomx=%d  wartosc = %d ", starty,startx,rtomy//(starty), rtomx(startx), tab[rtomy(starty)][rtomx(startx)]);//,tab[mtory(9)][mtorx(9)], mtorx(9), mtory//(9));                                  //..........................................................................................
//			break;
		
			//Spacja - zmiana położenia statku z poziomego na pionowe i odwrotnie
			case 32:
				
				for(i=0 ; i<size_of_ship ; i++) { 
					if (tab[rtomy(starty)][rtomx(startx)+i]==1) {
						flagx=1;
					}
				}
				
				for(i=0 ; i<size_of_ship ; i++) {
					if (tab[rtomy(starty)+i][rtomx(startx)]==1) {
						flagy=1;
					}
				}
				
				if(vertical==FALSE && flagy==FALSE && (starty+(size_of_ship-1)*step_up_down <= (n*step_up_down-1)  ) ) {	
					
					for (i=0 ; i< (size_of_ship) ; i++) {
						mvwaddch(local_win,starty,startx,' ');	
						startx = startx + step_left_right;
					}
							
					startx = startx - (size_of_ship)*step_left_right;

					for (i=0 ; i< (size_of_ship) ; i++) {
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
						starty = starty + step_up_down;
					}

					starty = starty - (size_of_ship)*step_up_down;
					mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
					
					vertical=1;
					wrefresh(local_win);				
				}

				else if(vertical==TRUE && flagx==FALSE && (startx+(size_of_ship-1)*step_left_right <= (n*step_left_right-2)) ) {
					for (i=0 ; i< (size_of_ship) ; i++) {
						mvwaddch(local_win,starty,startx,' ');	
						starty = starty + step_up_down;
					}
					
					starty = starty - step_up_down*size_of_ship;

					for (i=0 ; i< (size_of_ship) ; i++) {
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
						startx = startx + step_left_right;
					}

					startx = startx - step_left_right*size_of_ship;
					mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
					vertical=0;
					wrefresh(local_win);
				}

				flagy=FALSE;
				flagx=FALSE;

				break;

			// Enter - ustawienie statku
			case 10:
			if ((vertical==0 && check_if_around_pos_horizont (tab, rtomy(starty), rtomx(startx), size_of_ship)!=1)  
				||( vertical==1 && check_if_around_vertical (tab, rtomy(starty), rtomx(startx), size_of_ship)!=1)) {	
				
				if(vertical==0) {	
						
					tab[rtomy(starty)-1][rtomx(startx)]=2;						
					tab[rtomy(starty)-1][rtomx(startx)-1]=2;						
					tab[rtomy(starty)][rtomx(startx)-1]=2;						
					tab[rtomy(starty)+1][rtomx(startx)-1]=2;					
					tab[rtomy(starty)+1][rtomx(startx)]=2;					
						
					for (i=0 ; i < (size_of_ship - 1); i++) {
						tab[rtomy(starty)][rtomx(startx)]=1;
						
						startx = startx + step_left_right;
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
						
						tab[rtomy(starty)-1][rtomx(startx)]=2;						
						tab[rtomy(starty)+1][rtomx(startx)]=2;	
					}
						
					tab[rtomy(starty)][rtomx(startx)]=1;
					tab[rtomy(starty)-1][rtomx(startx)]=2;					
					tab[rtomy(starty)-1][rtomx(startx)+1]=2;					
					tab[rtomy(starty)][rtomx(startx)+1]=2;					
					tab[rtomy(starty)+1][rtomx(startx)+1]=2;					
					tab[rtomy(starty)+1][rtomx(startx)]=2;
						
				}

				else {
						
					tab[rtomy(starty)][rtomx(startx)-1]=2;						
					tab[rtomy(starty)-1][rtomx(startx)-1]=2;						
					tab[rtomy(starty)-1][rtomx(startx)]=2;						
					tab[rtomy(starty)-1][rtomx(startx)+1]=2;						
					tab[rtomy(starty)][rtomx(startx)+1]=2;						
										
					for (i=0 ; i < (size_of_ship-1); i++) {
							
						tab[rtomy(starty)][rtomx(startx)]=1;	
														
						starty = starty + step_up_down;
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);	
										
						tab[rtomy(starty)][rtomx(startx)-1]=2;					
						tab[rtomy(starty)][rtomx(startx)+1]=2;	
																						
					}
						
					tab[rtomy(starty)][rtomx(startx)]=1;					
					tab[rtomy(starty)][rtomx(startx)+1]=2;
					tab[rtomy(starty)+1][rtomx(startx)+1]=2;
					tab[rtomy(starty)+1][rtomx(startx)]=2;
					tab[rtomy(starty)+1][rtomx(startx)-1]=2;
					tab[rtomy(starty)][rtomx(startx)-1]=2;					
						
				  }
			

				players_ships=players_ships + size_of_ship;
				startx=2;
				starty=1;
				wmove(local_win,starty,startx);					
				vertical=0;	
						
				if (players_ships==0) {

					size_of_ship=4;

				}	
				if (players_ships==4) {

					size_of_ship=3;
					tab[rtomy(starty)][rtomx(startx)+1]=0;}
					
					if (players_ships==10) {
						size_of_ship=2;
						tab[rtomy(starty)][rtomx(startx)+2]=0;}
					}					
					
					if (players_ships==16) {
						size_of_ship=1;
						tab[rtomy(starty)][rtomx(startx)+3]=0;}
					}					
					
					if (players_ships==20) {
						endwin();
						return local_win;
					}
					
					for (i=0 ; i < (size_of_ship); i++) {
						mvwaddch(local_win,starty,startx,ACS_CKBOARD);
						startx = startx + step_left_right;
					}

					startx = startx - (size_of_ship)*step_left_right;
					wrefresh(local_win);
				}
		}// switcha	
	}// while

	getch();
	endwin();
	return local_win;
}*/
