#include "menu.h"
#include "game.h"

int main() {
	return battle_PvP(10);
	//return menu();
}

