#include <curses.h>
#include <stdlib.h>

/* (r)eal - to wartość dla kursora, (m)emory - to wartość w pamięci*/
#define rtomx(x) (((x+2)/4))
#define rtomy(y) (((y+1)/2))
#define mtorx(x) (4*(x)-2)
#define mtory(y) (2*(y)-1)

#define MAXLINE 50

#define NOTHING 	0
#define PLACED 		1
#define SURROUND 	2
#define MISSED 		3
#define HIT 		4

/*
void destroy_win(WINDOW *local_win);
int parsing(char *name);
WINDOW* load(int **tab, FILE *file, int height, int width, int starty_main, int startx_main);
int save(int **tab, FILE *file);
WINDOW *set_board_player(int height, int width, int starty_main, int startx_main, int **tab, int n);
WINDOW *set_board_enemy(int height, int width, int starty_main, int startx_main, int **tab, int n);
WINDOW *create_newwin(int height, int width, int starty_main, int startx_main);
*/
