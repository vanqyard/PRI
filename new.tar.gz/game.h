#include <ncurses.h>
#include <stdlib.h>
#define PRZEGRYWASZ 0 
#define WYGRYWASZ 	1
#define TORUS 		95
#define SQUARE 		96

int step_up_down 	= 2;
int step_left_right = 4;
int startx_main 	= 5;
int starty_main 	= 5;

WINDOW *create_newwin(int height, int width, int starty_main, int startx_main, int n);
WINDOW *set_board_player(int height, int width, int starty_main, int startx_main, int **tab, int n);

int check_if_around_pos_horizont(int **tab, int starty, int startx, int size);
int check_if_around_pos_vertical(int **tab, int starty, int startx, int size);

void destroy_win(WINDOW *local_win, int n);

int battle_PvP(int n);



























//int battle_PvP(WINDOW *players_win, WINDOW *enemys_win, int **board_p, int **board_e, int n); 
//int players_shot(int **tab_player, int **tab_enemy, WINDOW *local_win, int n);

/*
int battle_pvsc_easy(WINDOW *players_win, WINDOW *enemys_win, int **players_board, int **enemys_board, int n);  
int battle_pvsc_normal(WINDOW *players_win, WINDOW *enemys_win, int **players_board, int **enemys_board, int n);
int battle_pvsc_hard(WINDOW *players_win, WINDOW *enemys_win, int **players_board, int **enemys_board, int n);  
int players_shot(int **tab, int **tab2, WINDOW *local_win, int n);
int enemys_shot(int **tab, WINDOW *local_win, int n);
int normal_enemys_shot(int **tab, WINDOW *local_win, int n, int memox, int memoy);
*/
